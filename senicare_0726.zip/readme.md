커밋내용
1. 지인
- 멤버 컨트롤러 로그인 기능 추가 0728 18:16

2. 영섭 (07/30 02:29)
- AuthServiceImpl 에서 로그인한 회원의 닉네임 세션에 저장시킴
- 기존 ${sessionId} 를 ${sessionScope.id} 로 변경
- searchHos, madang, health 헤드배너 수정안으로 변경
- main_header에서 health_2로 갈 때 session id 전달하는 주소로 바꿈
- health_1, health_2 집에선 CSS 적용된 모습으로 보여서 태그 내부 style 서식 주석처리함

