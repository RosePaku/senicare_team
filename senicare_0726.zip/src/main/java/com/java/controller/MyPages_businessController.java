package com.java.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.java.dto.A_B;
import com.java.service.MyPages_businessService;

@Controller
@RequestMapping("/myPages_business_folder")
public class MyPages_businessController {

	@Autowired
	private MyPages_businessService mypages_businessservice;

	// 회원 정보 가져오기
	@PostMapping("/myPages_business_1")
	public String MyPages_businessController_1(Model model) {
		List<A_B> A_BList = mypages_businessservice.getAllA_B();
		System.out.println("A_BController A_BList : " +
				A_BList.size());
		System.out.println(A_BList.get(0).getAuth_business_id());
		for (int i = 0; i < 10; i++) {
			System.out.println(A_BList.get(i).getAuth_business_no_1());
		}

		model.addAttribute("A_BList", A_BList);
		return "myPages_business_folder/myPages_business_1";

	}

	// 회원정보 가져오기
	@GetMapping("/myPages_business_1")
	public String gMyPages_businessController_1(Model model) {
		List<A_B> A_BList = mypages_businessservice.getAllA_B();
		System.out.println("A_BController A_BList : " +
				A_BList.size());
		System.out.println(A_BList.get(0).getAuth_business_id());
		for (int i = 0; i < 10; i++) {
			System.out.println(A_BList.get(i).getAuth_business_no_1());
		}

		model.addAttribute("A_BList", A_BList);
		return "myPages_business_folder/myPages_business_1";

	}

	// 회원 정보 업데이트
	@PostMapping("/update")
	public String updateMyPages_businessController_1(A_B updatedA_B, Model model) {
		mypages_businessservice.updateA_B(updatedA_B);
		System.out.println(updatedA_B.getAuth_business_email());
		// List<A_B> updatedA_BList = mypages_businessservice.getAllA_B();

		// System.out.println("A_BController updatedA_BList : " +
		// updatedA_BList.size());
		// System.out.println(updatedA_BList.get(0).getAuth_business_id());
		// for (int i = 0; i < 10; i++) {
		// System.out.println(updatedA_BList.get(i).getAuth_business_no_1());
		// }

		// model.addAttribute("A_BList", updatedA_BList);
		return "redirect:/";

	}

	// 회원정보 가져오기
	// @GetMapping("/myPages_business_1={update}")
	// public String ugMyPages_businessController_1(Model model) {
	// List<A_B> A_BList = mypages_businessservice.getAllA_B();
	// System.out.println("A_BController A_BList : " +
	// A_BList.size());
	// System.out.println(A_BList.get(0).getAuth_business_id());
	// for (int i = 0; i < 10; i++) {
	// System.out.println(A_BList.get(i).getAuth_business_no_1());
	// }

	// model.addAttribute("A_BList", A_BList);
	// return "myPages_business_folder/myPages_business_1";

	// }

	// 가져오기 일단은
	// @GetMapping("/myPages_business_1")
	// public String gMyPages_businessController_1(@RequestParam("id") int
	// AUTH_BUSINESS_ID, Model model) {
	// A_B a_b = mypages_businessservice.getMemberById(AUTH_BUSINESS_ID);
	// model.addAttribute("A_B", a_b);
	// return "/myPages_business_1";

	// }

	// @PostMapping("/myPages_business_1/edit")
	// public A_B MyPages_businessController_1(Model model, A_B a_b) {
	// A_B a_b = MyPages_businessService.updateComOne(a_b);
	//
	// return "/myPages_business_1";
	//
	// }

	@PostMapping("/myPages_business_2_1")
	public String MyPages_businessController_2_1(Model model) {

		return "/myPages_business_2_1";

	}

	@GetMapping("/myPages_business_2_1")
	public String gMyPages_businessController_2_1(Model model) {
		return "/myPages_business_2_1";

	}

	@PostMapping("/myPages_business_2_2")
	public String MyPages_businessController_2_2(Model model) {

		return "/myPages_business_2_2";

	}

	@PostMapping("/myPages_business_3")
	public String MyPages_businessController_3(Model model) {
		return "/myPages_business_3";

	}

	@GetMapping("/myPages_business_3")
	public String gMyPages_businessController_3(Model model) {
		return "/myPages_business_3";

	}

	@PostMapping("/myPages_business_4")
	public String MyPages_businessController_4(Model model) {
		return "/myPages_business_4";

	}

	@GetMapping("/myPages_business_4")
	public String gMyPages_businessController_4(Model model) {
		return "/myPages_business_4";

	}

	@PostMapping("/myPages_business_5")
	public String MyPages_businessController_5(Model model) {
		return "/myPages_business_5";

	}

	@GetMapping("/myPages_business_5")
	public String gMyPages_businessController_5(Model model) {
		return "/myPages_business_5";

	}

	@PostMapping("/myPages_business_6")
	public String MyPages_businessController_6(Model model) {
		return "/myPages_business_6";

	}

	@GetMapping("/myPages_business_6")
	public String gMyPages_businessController_6(Model model) {
		return "/myPages_business_6";

	}

}
