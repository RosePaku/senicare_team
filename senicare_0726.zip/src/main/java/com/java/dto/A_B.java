//지원정보 데이터
package com.java.dto;

import java.sql.Timestamp;
import java.util.Date;

public class A_B {

	public String getAuth_business_id() {
		return auth_business_id;
	}

	public void setAuth_business_id(String auth_business_id) {
		this.auth_business_id = auth_business_id;
	}

	public String getAuth_business_password() {
		return auth_business_password;
	}

	public void setAuth_business_password(String auth_business_password) {
		this.auth_business_password = auth_business_password;
	}

	public String getAuth_business_sex() {
		return auth_business_sex;
	}

	public void setAuth_business_sex(String auth_business_sex) {
		this.auth_business_sex = auth_business_sex;
	}

	public Date getAuth_business_birth() {
		return auth_business_birth;
	}

	public void setAuth_business_birth(Date auth_business_birth) {
		this.auth_business_birth = auth_business_birth;
	}

	public String getAuth_business_ceo_name_2() {
		return auth_business_ceo_name_2;
	}

	public void setAuth_business_ceo_name_2(String auth_business_ceo_name_2) {
		this.auth_business_ceo_name_2 = auth_business_ceo_name_2;
	}

	public String getAuth_business_nickname() {
		return auth_business_nickname;
	}

	public void setAuth_business_nickname(String auth_business_nickname) {
		this.auth_business_nickname = auth_business_nickname;
	}

	public String getAuth_business_email() {
		return auth_business_email;
	}

	public void setAuth_business_email(String auth_business_email) {
		this.auth_business_email = auth_business_email;
	}

	public String getAuth_business_address() {
		return auth_business_address;
	}

	public void setAuth_business_address(String auth_business_address) {
		this.auth_business_address = auth_business_address;
	}

	public String getAuth_business_address_detail() {
		return auth_business_address_detail;
	}

	public void setAuth_business_address_detail(String auth_business_address_detail) {
		this.auth_business_address_detail = auth_business_address_detail;
	}

	public String getAuth_business_phone_number() {
		return auth_business_phone_number;
	}

	public void setAuth_business_phone_number(String auth_business_phone_number) {
		this.auth_business_phone_number = auth_business_phone_number;
	}

	public String getAuth_business_clause_yn_1() {
		return auth_business_clause_yn_1;
	}

	public void setAuth_business_clause_yn_1(String auth_business_clause_yn_1) {
		this.auth_business_clause_yn_1 = auth_business_clause_yn_1;
	}

	public String getAuth_business_personal_yn() {
		return auth_business_personal_yn;
	}

	public void setAuth_business_personal_yn(String auth_business_personal_yn) {
		this.auth_business_personal_yn = auth_business_personal_yn;
	}

	public Timestamp getAuth_business_join_dt() {
		return auth_business_join_dt;
	}

	public void setAuth_business_join_dt(Timestamp auth_business_join_dt) {
		this.auth_business_join_dt = auth_business_join_dt;
	}

	public Timestamp getAuth_business_del_dt() {
		return auth_business_del_dt;
	}

	public void setAuth_business_del_dt(Timestamp auth_business_del_dt) {
		this.auth_business_del_dt = auth_business_del_dt;
	}

	public String getAuth_business_user_status() {
		return auth_business_user_status;
	}

	public void setAuth_business_user_status(String auth_business_user_status) {
		this.auth_business_user_status = auth_business_user_status;
	}

	public String getAuth_business_img_1() {
		return auth_business_img_1;
	}

	public void setAuth_business_img_1(String auth_business_img_1) {
		this.auth_business_img_1 = auth_business_img_1;
	}

	public String getAuth_business_no_1() {
		return auth_business_no_1;
	}

	public void setAuth_business_no_1(String auth_business_no_1) {
		this.auth_business_no_1 = auth_business_no_1;
	}

	public String getAuth_info_storage_1() {
		return auth_info_storage_1;
	}

	public void setAuth_info_storage_1(String auth_info_storage_1) {
		this.auth_info_storage_1 = auth_info_storage_1;
	}

	private String auth_business_id;
	private String auth_business_password;
	private String auth_business_sex;
	private Date auth_business_birth;
	private String auth_business_ceo_name_2;
	private String auth_business_nickname;
	private String auth_business_email;
	private String auth_business_address;
	private String auth_business_address_detail;
	private String auth_business_phone_number;
	private String auth_business_clause_yn_1;
	private String auth_business_personal_yn;
	private Timestamp auth_business_join_dt;
	private Timestamp auth_business_del_dt;
	private String auth_business_user_status;
	private String auth_business_img_1;
	private String auth_business_no_1;
	private String auth_info_storage_1;

	// getter, setter 메서드들...
}
