package com.java.dto;

import java.util.Date;

public class Auth_Vol {
    public String getAuth_vol_no() {
		return auth_vol_no;
	}
	public void setAuth_vol_no(String auth_vol_no) {
		this.auth_vol_no = auth_vol_no;
	}
	public String getAuth_id() {
		return auth_id;
	}
	public void setAuth_id(String auth_id) {
		this.auth_id = auth_id;
	}
	public String getAuth_self_intro() {
		return auth_self_intro;
	}
	public void setAuth_self_intro(String auth_self_intro) {
		this.auth_self_intro = auth_self_intro;
	}
	public String getAuth_certi() {
		return auth_certi;
	}
	public void setAuth_certi(String auth_certi) {
		this.auth_certi = auth_certi;
	}
	public String getAuth_port() {
		return auth_port;
	}
	public void setAuth_port(String auth_port) {
		this.auth_port = auth_port;
	}
	public Date getAuth_work_date() {
		return auth_work_date;
	}
	public void setAuth_work_date(Date auth_work_date) {
		this.auth_work_date = auth_work_date;
	}
	public String getAuth_other_note() {
		return auth_other_note;
	}
	public void setAuth_other_note(String auth_other_note) {
		this.auth_other_note = auth_other_note;
	}
	public String getAuth_keyword() {
		return auth_keyword;
	}
	public void setAuth_keyword(String auth_keyword) {
		this.auth_keyword = auth_keyword;
	}
	public String getAuth_career() {
		return auth_career;
	}
	public void setAuth_career(String auth_career) {
		this.auth_career = auth_career;
	}
	public String getAuth_school() {
		return auth_school;
	}
	public void setAuth_school(String auth_school) {
		this.auth_school = auth_school;
	}
	private String auth_vol_no;
    private String auth_id;
    private String auth_self_intro;
    private String auth_certi;
    private String auth_port;
    private Date auth_work_date;
    private String auth_other_note;
    private String auth_keyword;
    private String auth_career;
    private String auth_school;
    
    

    // getter, setter 메서드들...
}
