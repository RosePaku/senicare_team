// 채용공고 
function viewPost(id) {
    // 여기에 채용공고 조회를 위한 코드를 작성하세요.
    console.log("조회: " + id);
}

function editPost(id) {
    // 여기에 채용공고 수정을 위한 코드를 작성하세요.
    console.log("수정: " + id);
}

function deletePost(id) {
    // 여기에 채용공고 삭제를 위한 코드를 작성하세요.
    console.log("삭제: " + id);
}

